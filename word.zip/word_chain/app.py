from flask import Flask, jsonify, request, render_template
from game_engine import GameEngine

app = Flask(__name__)
game = GameEngine()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    return jsonify(game.try_login(int(data['role']), data.get('token')))

@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    data = request.json
    role, token = int(data.get('role')), data.get('token')
    if game.seats[role] == token:
        game.last_seen[role] = __import__('time').time()
        return jsonify({"status": "ok"})
    return jsonify({"status": "error"})

@app.route('/get_state')
def get_state():
    return jsonify(game.get_state_dict())

@app.route('/make_move', methods=['POST'])
def make_move():
    data = request.json
    error = game.validate_move(
        int(data['role']), data['token'], 
        int(data['row']), int(data['col']), data['letter'].upper()
    )
    if error: return jsonify({"status": "error", "message": error})
    return jsonify({"status": "success"})

@app.route('/end_turn', methods=['POST'])
def end_turn():
    data = request.json
    error = game.end_turn(int(data['role']), data['token'], int(data['points']))
    if error: return jsonify({"status": "error", "message": error})
    return jsonify(game.get_state_dict())

@app.route('/set_target', methods=['POST'])
def set_target():
    game.target_score = int(request.json['target'])
    return jsonify({"status": "success"})

@app.route('/reset', methods=['POST'])
def reset():
    game.reset()
    return jsonify({"status": "reset"})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
