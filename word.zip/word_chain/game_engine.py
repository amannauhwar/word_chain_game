import uuid
import time

class GameEngine:
    def __init__(self):
        self.board = [['' for _ in range(10)] for _ in range(10)]
        self.scores = {1: 0, 2: 0}
        self.turn = 1
        self.locked_cells = []
        self.seats = {1: None, 2: None}
        self.target_score = 50
        self.winner = None
        self.last_seen = {1: 0, 2: 0}
        self.player_timeout = 5

    def clean_zombies(self):
        """Kicks out players who haven't sent a heartbeat recently"""
        now = time.time()
        for role in [1, 2]:
            if self.seats[role] is not None:
                if now - self.last_seen[role] > self.player_timeout:
                    print(f"Player {role} timed out.")
                    self.seats[role] = None

    def try_login(self, role, token):
        self.clean_zombies()
        
        # New Player
        if self.seats[role] is None:
            new_token = str(uuid.uuid4())
            self.seats[role] = new_token
            self.last_seen[role] = time.time()
            return {"status": "success", "token": new_token}
        
        # Reconnecting Player
        elif self.seats[role] == token:
            self.last_seen[role] = time.time()
            return {"status": "success", "token": token}
            
        return {"status": "error", "message": "Seat taken"}

    def validate_move(self, role, token, r, c, letter):
        # 1. Security Checks
        if self.winner: return "Game Over"
        if self.seats[role] != token: return "Invalid Identity"
        if role != self.turn: return "Not your turn"
        
        # 2. Game Rule: One Box Only
        if letter != "":
            for row in range(10):
                for col in range(10):
                    if (row != r or col != c):
                        if self.board[row][col] != "":
                            if [row, col] not in self.locked_cells:
                                return "Finish your current active tile first!"
        
        # 3. Apply Move
        self.last_seen[role] = time.time()
        self.board[r][c] = letter
        return None  # None means Success

    def end_turn(self, role, token, points):
        if self.winner: return "Game Over"
        if self.seats[role] != token or role != self.turn: return "Invalid Action"

        # --- FIX: THE NO FREE LUNCH RULE ---
        # Scan the board to see if there is a 'fresh' letter
        has_active_move = False
        for r in range(10):
            for c in range(10):
                # If there is a letter AND it is not in the locked list...
                if self.board[r][c] != "" and [r, c] not in self.locked_cells:
                    has_active_move = True
                    break
        
        if not has_active_move:
            return "You must place a letter before ending your turn!"
        # -----------------------------------

        self.last_seen[role] = time.time()
        self.scores[self.turn] += points

        if self.scores[self.turn] >= self.target_score:
            self.winner = self.turn

        # Lock Cells
        for r in range(10):
            for c in range(10):
                if self.board[r][c] != "":
                    if [r, c] not in self.locked_cells:
                        self.locked_cells.append([r, c])
        
        self.turn = 2 if self.turn == 1 else 1
        return None

    def reset(self):
        self.board = [['' for _ in range(10)] for _ in range(10)]
        self.scores = {1: 0, 2: 0}
        self.turn = 1
        self.locked_cells = []
        self.winner = None

    def get_state_dict(self):
        self.clean_zombies()
        return {
            "board": self.board,
            "scores": self.scores,
            "turn": self.turn,
            "locked_cells": self.locked_cells,
            "seats_taken": {1: self.seats[1] is not None, 2: self.seats[2] is not None},
            "target_score": self.target_score,
            "winner": self.winner
        }